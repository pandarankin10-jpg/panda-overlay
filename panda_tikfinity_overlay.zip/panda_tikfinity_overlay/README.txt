Panda Heart TikFinity Overlay

What is included:
- index.html
- style.css
- script.js

How to use:
1. Extract this ZIP.
2. Open index.html in your browser to test it.
3. Click "Test Panda Hearts" or "Test Gift Alert".
4. In OBS, add a Browser Source and choose the local index.html file.
5. In TikTok LIVE Studio, add it as a browser/link/local source depending on your setup.
6. Add ?live=1 to the end of the URL/file path to hide the test buttons.

TikFinity connection:
- This pack includes a starter WebSocket function in script.js.
- Open script.js and uncomment this line near the bottom:
  connectTikFinityWebSocket();
- The default WebSocket URL is ws://localhost:21213/.
- If your TikFinity API page shows a different port or event names, update them in script.js.

You can edit:
- Heart colour in pandaHeartSvg() inside script.js.
- Animation speed in style.css.
- Gift alert text in spawnGiftAlert() inside script.js.

Made as an original overlay pack.
