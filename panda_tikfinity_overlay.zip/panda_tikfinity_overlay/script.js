const overlay = document.getElementById('overlay');

function pandaHeartSvg() {
  return `
  <svg viewBox="0 0 100 100" aria-hidden="true">
    <defs>
      <radialGradient id="greenGloss" cx="35%" cy="25%" r="75%">
        <stop offset="0%" stop-color="#d8ff9b"/>
        <stop offset="45%" stop-color="#39ff14"/>
        <stop offset="100%" stop-color="#0b7d16"/>
      </radialGradient>
    </defs>
    <path fill="url(#greenGloss)" stroke="#b7ff65" stroke-width="3"
      d="M50 91 L16 58 C-2 40 5 14 27 14 C39 14 47 22 50 31 C53 22 61 14 73 14 C95 14 102 40 84 58 Z" />
    <ellipse cx="50" cy="54" rx="25" ry="22" fill="#fff"/>
    <circle cx="35" cy="36" r="9" fill="#111"/>
    <circle cx="65" cy="36" r="9" fill="#111"/>
    <ellipse cx="40" cy="54" rx="8" ry="11" fill="#111"/>
    <ellipse cx="60" cy="54" rx="8" ry="11" fill="#111"/>
    <circle cx="42" cy="51" r="2.5" fill="#fff"/>
    <circle cx="62" cy="51" r="2.5" fill="#fff"/>
    <ellipse cx="50" cy="62" rx="4" ry="3" fill="#111"/>
    <path d="M46 68 Q50 72 54 68" fill="none" stroke="#111" stroke-width="2" stroke-linecap="round"/>
    <path d="M50 66 Q50 72 50 74" fill="none" stroke="#111" stroke-width="2" stroke-linecap="round"/>
    <ellipse cx="50" cy="74" rx="5" ry="3" fill="#ff6fae"/>
    <path d="M25 29 C30 20 40 20 46 28" fill="none" stroke="#eaffcf" stroke-width="5" stroke-linecap="round" opacity=".65"/>
  </svg>`;
}

function spawnHeart() {
  const heart = document.createElement('div');
  heart.className = 'panda-heart';
  heart.innerHTML = pandaHeartSvg();

  const size = 48 + Math.random() * 58;
  const duration = 3.2 + Math.random() * 2.2;
  heart.style.setProperty('--size', `${size}px`);
  heart.style.setProperty('--left', `${Math.random() * 92}vw`);
  heart.style.setProperty('--duration', `${duration}s`);
  heart.style.setProperty('--drift', `${Math.random() * 260 - 130}px`);
  heart.style.setProperty('--scale', `${0.85 + Math.random() * 0.9}`);
  heart.style.setProperty('--rotate', `${Math.random() * 50 - 25}deg`);

  overlay.appendChild(heart);
  setTimeout(() => heart.remove(), duration * 1000 + 300);
}

function burstHearts(amount = 8) {
  for (let i = 0; i < amount; i++) {
    setTimeout(spawnHeart, i * 80);
  }
  spawnSparkles(12);
}

function spawnSparkles(amount = 8) {
  for (let i = 0; i < amount; i++) {
    const sparkle = document.createElement('div');
    sparkle.className = 'sparkle';
    sparkle.style.left = `${20 + Math.random() * 60}vw`;
    sparkle.style.top = `${20 + Math.random() * 60}vh`;
    overlay.appendChild(sparkle);
    setTimeout(() => sparkle.remove(), 1500);
  }
}

function spawnGiftAlert(username = 'viewer', gift = 'gift') {
  const alert = document.createElement('div');
  alert.className = 'gift-alert';
  alert.textContent = `🐼 ${username} sent ${gift}! 💚`;
  overlay.appendChild(alert);
  burstHearts(18);
  setTimeout(() => alert.remove(), 3200);
}

// Demo mode: add ?live=1 to the URL to hide test buttons.
if (new URLSearchParams(location.search).get('live') === '1') {
  document.body.classList.add('live-mode');
}

// Optional TikFinity WebSocket starter.
// The exact local port/event names can vary, so adjust this to your TikFinity API page settings.
function connectTikFinityWebSocket() {
  try {
    const socket = new WebSocket('ws://localhost:21213/');

    socket.onmessage = (event) => {
      let data;
      try { data = JSON.parse(event.data); } catch { return; }
      const eventName = String(data.event || data.type || '').toLowerCase();

      if (eventName.includes('like')) burstHearts(5);
      if (eventName.includes('gift')) spawnGiftAlert(data.nickname || data.username || 'viewer', data.giftName || 'a gift');
      if (eventName.includes('follow')) burstHearts(12);
    };
  } catch (error) {
    console.log('TikFinity WebSocket not connected yet.', error);
  }
}

// Uncomment this when you are ready to test with TikFinity:
// connectTikFinityWebSocket();
